
#whether the string is palindrome or not

def polindrome(string):
    if string ==string[::-1]:
        return "polindrome"
    else:
        return "not a polindrome"
print(polindrome("malayalam"))
print(polindrome("python"))
print(polindrome("madam"))
print(polindrome("level"))
print(polindrome("java"))

# whether the number is armstrong or not
sum1 =0
def armstrong(num):
    
    for i in num:
        arm = int(i)**3
        sum1 = sum1+arm
        
    
    if sum1==int(num):
        return "armstrong"
    else:
        return "not a amstrong"
print(armstrong("123"))
    

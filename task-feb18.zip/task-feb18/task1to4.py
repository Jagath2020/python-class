
#User Def functions (4)
#Write function to concatenate three strings
#Write a function multiply three different integers and return a int
#Write a function to return middle char of the string
#write a function to return whether middle character is vowel or not 

#Write function to concatenate three strings

def my_function(x,y,z):
    return x+y+z
print(my_function("python","java","c"))

#Write a function multiply three different integers and return a int
def my_function(x,y,z):
     return x*y*z
print(my_function(4,7,6))

#Write a function to return middle char of the string
def my_function(string):
    return string[(len(string)//2)]
print(my_function("python"))
print(my_function("bbb"))
print(my_function("java"))

#write a function to return whether middle character is vowel or not

#vowels = ('a','e','i','o','u')

def my_function(string):
     mid = string[(len(string)//2)]
     print(mid)
     
if (string=='a',string=='e',string=='i',string=='o',string=='u'):
        print(mid,"is a vowel")
    
print(my_function("python"))

